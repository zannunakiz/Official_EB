# Folder A

This is a sample folder inside PROJECT_CONTEXT.
It contains project metadata and components.
