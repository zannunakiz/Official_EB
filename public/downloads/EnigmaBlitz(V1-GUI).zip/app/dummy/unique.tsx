
const unique = () => {
   return (
      <div>unique test for EB 2.0</div>
   )
}

export default unique