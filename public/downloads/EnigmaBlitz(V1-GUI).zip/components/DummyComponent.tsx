
const DummyComponent = () => {
   return (
      <div>DummyComponent test for 2.0 EB</div>
   )
}

export default DummyComponent