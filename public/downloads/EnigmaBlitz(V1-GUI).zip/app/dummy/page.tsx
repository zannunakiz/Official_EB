
const page = () => {
   return (
      <div>Dummy page for testing 2.0</div>
   )
}

export default page